# Ori and the Will of the Wisps - 4:3 Aspect Ratio Fix

This ASI plugin forces a native 4:3 aspect ratio in *Ori and the Will of the Wisps* by dynamically hooking both the logical camera (`GameAssembly.dll`) and the rendering engine (`UnityPlayer.dll`). 

Perfect for 4:3 retro handhelds (like the Retroid Pocket Nova) running the game via Winlator or standard Wine environments.

## Installation

1. Copy **`version.dll`** (Ultimate ASI Loader) and **`OriARFix.asi`** into your game's root directory (the same folder as `OriAndTheWilloftheWisps.exe`).
2. **For Winlator / Wine users (CRITICAL):** You must configure the environment variables so Wine loads the custom DLL instead of the built-in system one.
   * Open your Winlator Container Settings (or Shortcut Settings).
   * Go to **Environment Variables**.
   * Add the following entry:
     `WINEDLLOVERRIDES="version=n,b"`

## Verification & Configuration
* Launch the game. If the plugin is loaded successfully, an `OriARFix.log` file will be generated in the game folder.
* (Optional) You can create an `OriARFix.ini` in the game folder to set custom aspect ratios:
  ```ini
  [AspectRatio]
  TargetWidth = 4.0
  TargetHeight = 3.0